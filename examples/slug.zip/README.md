Fix slugify to collapse whitespace, strip surrounding spaces, and lowercase text.

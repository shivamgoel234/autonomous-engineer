def slugify(text):
    """Normalize a title into a simple URL slug."""
    return text.replace(" ", "-")

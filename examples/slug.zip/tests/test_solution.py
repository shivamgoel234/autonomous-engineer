from src.solution import slugify


def test_lowercase():
    assert slugify("Hello World") == "hello-world"


def test_surrounding_space():
    assert slugify("  hello  ") == "hello"


def test_repeated_whitespace():
    assert slugify("Hello   World\tAgain") == "hello-world-again"


def test_empty():
    assert slugify("   ") == ""

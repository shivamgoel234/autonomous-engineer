import pytest
from src.solution import median


def test_odd_unsorted():
    assert median([9, 1, 5]) == 5


def test_even():
    assert median([1, 9, 3, 7]) == 5


def test_input_unchanged():
    values = [9, 1, 5]
    median(values)
    assert values == [9, 1, 5]


def test_empty():
    with pytest.raises(ValueError):
        median([])

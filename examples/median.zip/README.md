Fix median: sort without mutating input, average even-length middles, reject empty.

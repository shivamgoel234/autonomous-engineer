def median(values):
    """Return the median of a sequence of numbers."""
    return values[len(values) // 2]

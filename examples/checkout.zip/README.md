Fix calculate_total: include item quantities and reject discounts outside 0..1.

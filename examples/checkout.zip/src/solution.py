def calculate_total(items, discount=0.0):
    """Return the discounted checkout total."""
    subtotal = sum(item["price"] for item in items)
    return round(subtotal * (1 - discount), 2)

import pytest
from src.solution import calculate_total


def test_quantities():
    assert calculate_total([{"price": 10, "quantity": 3}]) == 30


def test_discount():
    assert calculate_total([{"price": 20, "quantity": 2}], 0.25) == 30


def test_empty_cart():
    assert calculate_total([]) == 0


@pytest.mark.parametrize("discount", [-0.1, 1.1])
def test_invalid_discount(discount):
    with pytest.raises(ValueError):
        calculate_total([], discount)
